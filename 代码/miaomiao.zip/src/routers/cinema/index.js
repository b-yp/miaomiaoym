export default {
    path : '/cinema',
    component : () => import('@/views/Cinema')
}